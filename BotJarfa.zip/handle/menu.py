import discord, json
from discord.ext import commands
from samp.basic import Basic
from samp.performance import Performance
from mc.basic import BasicMC
from discord.ui import Select, View

warna = 0x2C2D31
with open('./config.json') as c:
  config = json.load(c)
  ICON = config['ICON']
  PANEL_IMAGE = config['PANEL_IMAGE']

class Select(discord.ui.Select):
  def __init__(self):
    options=[
      discord.SelectOption(label="SA-MP Basic Cloud",emoji="<:samp:1173194947227299880>",value="1",description="SA-MP AMD EPYC (Sharing)"),
      discord.SelectOption(label="SA-MP Performance Cloud",emoji="<:samp:1173194947227299880>",value="2",description="SA-MP AMD RYZEN 5950X (Sharing)"),
      discord.SelectOption(label="Minecraft Basic Cloud",emoji="<:minecraft:1182004196879380530>",value="3",description="MINECRAFT AMD EPYC (Sharing)"),
      discord.SelectOption(label="Bot Hosting Cloud",emoji="<:discord:1179761180496101396>",value="4",description="Daftar harga hosting bot."),
      discord.SelectOption(label="Jasa SA-MP",emoji="👷",value="5",description="Jasa SA-MP list harga"),
      ]
    super().__init__(placeholder="📦 Pilih untuk melihat produk!",max_values=4,min_values=1,options=options)
  async def callback(self, interaction: discord.Interaction):
    if self.values[0] == "1":
      embed = discord.Embed(title="",color=warna, description = """## <:samp:1173194947227299880>Hosting SA-MP Basic

```Basic cloud rekomendasi untuk server menengah kebawah dengan harga yang sangat murah, untuk kecepatan sangat bagus ping rendah dan sudah ada anti DDoS Basic\n\nCpu: ∞\nRam: ∞\nDisk: ∞\nBandwidth: ∞```
<:paket:1179761619786534983>**__Paket#1 (25 SLOT) <:panah:1179771346855678002> Rp25,000__**
<:paket:1179761619786534983>**__Paket#2 (35 SLOT) <:panah:1179771346855678002> Rp35,000__**
<:paket:1179761619786534983>**__Paket#3 (50 + 10 SLOT) <:panah:1179771346855678002> Rp50,000__**
<:paket:1179761619786534983>**__Paket#4 (70 + 15 SLOT) <:panah:1179771346855678002> Rp70,000__**
<:paket:1179761619786534983>**__Paket#5 (100 + 25 SLOT) <:panah:1179771346855678002> Rp100,000__**
<:apalah:1179761511367975023>
  <:tambah_iconXCloud2:1179773147231293530>Include Database Online
  <:tambah_iconXCloud2:1179773147231293530>Include Autobackup Setiap 1 Jam
  <:tambah_iconXCloud2:1179773147231293530>Include Panel Management - untuk mengontrol server
  <:tambah_iconXCloud2:1179773147231293530>Include SFTP untuk memudahkan transfer file
  <:tambah_iconXCloud2:1179773147231293530>Include Anti DDoS Basic by Lost Cloud

### <:informasi:1181621768646053969>Information
Untuk menggunakan hosting ini anda bisa custom egg **Windows** & **Ubuntu** sesuai gamemodes anda .so atau plugin windows.

📮Mau order bisa langsung [Pesan Sekarang](https://discord.com/channels/1100826060188299360/1172910051560804554)

🎮**__Tampilan Hosting__**
      """)
      embed.set_footer(text='Please click "Dismiss Message" to clear the menu.', icon_url=ICON)
      embed.set_image(url=PANEL_IMAGE)
      await interaction.response.send_message(embed=embed, view=Basic(), ephemeral=True)
    elif self.values[0] == "2":
      embed = discord.Embed(title="",color=warna, description = """## <:samp:1173194947227299880>Hosting SA-MP Performance

```Performance rekomendasi untuk server menengah keatas dengan harga yang sangat murah, untuk kecepatan sangat bagus ping rendah dan sudah ada anti DDoSv2\n\nCpu: ∞\nRam: ∞\nDisk: ∞\nBandwidth: ∞```
<:paket:1179761619786534983>**__Paket#1 (50 + 5 SLOT) <:panah:1179771346855678002> Rp50,000__**
<:paket:1179761619786534983>**__Paket#2 (80 + 10 SLOT) <:panah:1179771346855678002> Rp80,000__**
<:paket:1179761619786534983>**__Paket#3 (100 + 25 SLOT) <:panah:1179771346855678002> Rp120,000__**
<:apalah:1179761511367975023>
  <:tambah_iconXCloud2:1179773147231293530>Include Bot Monitoring Servers
  <:tambah_iconXCloud2:1179773147231293530>Include Database Online
  <:tambah_iconXCloud2:1179773147231293530>Include Autobackup Setiap 1 Jam
  <:tambah_iconXCloud2:1179773147231293530>Include Panel Management - untuk mengontrol server
  <:tambah_iconXCloud2:1179773147231293530>Include SFTP untuk memudahkan transfer file
  <:tambah_iconXCloud2:1179773147231293530>Include Anti DDoS Basic by XCloud

### <:informasi:1181621768646053969>Information
Untuk menggunakan hosting ini anda bisa custom egg **Windows** & **Ubuntu** sesuai gamemodes anda .so atau plugin windows.

📮Mau order bisa langsung [Pesan Sekarang](https://discord.com/channels/1100826060188299360/1172910051560804554)

🎮**__Tampilan Hosting__**
      """)
      embed.set_footer(text='Please click "Dismiss Message" to clear the menu.', icon_url=ICON)
      embed.set_image(url=PANEL_IMAGE)
      await interaction.response.send_message(embed=embed, view=Performance(), ephemeral=True)
    elif self.values[0] == "3":
      embed = discord.Embed(title="",color=warna, description = """## <:minecraft:1182004196879380530>Hosting Minecraft Basic

```Basic cloud rekomendasi untuk server menengah kebawah dengan harga yang sangat murah, untuk kecepatan sangat bagus ping rendah dan sudah ada anti DDoS Basic\n\nCpu: ∞\nRam: ∞\nDisk: ∞\nBandwidth: ∞```
<:paket:1179761619786534983>**__Paket#1 (25 SLOT) <:panah:1179771346855678002> Rp35,000__**
<:paket:1179761619786534983>**__Paket#2 (35 SLOT) <:panah:1179771346855678002> Rp50,000__**
<:paket:1179761619786534983>**__Paket#5 (80 SLOT) <:panah:1179771346855678002> Rp125,000__**
<:apalah:1179761511367975023>
  <:tambah_iconXCloud2:1179773147231293530>Include Database Online - Phpmyadmin Access
  <:tambah_iconXCloud2:1179773147231293530>Include Panel Management - untuk mengontrol server
  <:tambah_iconXCloud2:1179773147231293530>Include SFTP untuk memudahkan transfer file
  <:tambah_iconXCloud2:1179773147231293530>Include Anti DDoS Basic by XCloud

### <:informasi:1181621768646053969>Information
Untuk hosting ini adalah sharing, untuk Minecraft menggunakan egg Custom

📮Mau order bisa langsung [Pesan Sekarang](https://discord.com/channels/1100826060188299360/1172910051560804554)

🎮**__Tampilan Hosting__**
      """)
      embed.set_footer(text='Please click "Dismiss Message" to clear the menu.', icon_url=ICON)
      embed.set_image(url=PANEL_IMAGE)
      await interaction.response.send_message(embed=embed, view=BasicMC(), ephemeral=True)
    elif self.values[0] == "4":
      embed = discord.Embed(title="", color=warna, description="""## 🤖Hosting Bot Cloud
      
```Kami menyediakan hosting bot untuk UCP dan untuk lainnya sebagai```
<:paket:1179761619786534983>**__Harga <:panah:1179771346855678002> Rp10.000__**
<:apalah:1179761511367975023>
  <:tambah_iconXCloud2:1179773147231293530>Include Online 24/7 Jam
  <:tambah_iconXCloud2:1179773147231293530>Include Support Nodejs or Python

📮Mau order bisa langsung [Pesan Sekarang](https://discord.com/channels/1100826060188299360/1172910051560804554)
      """)
      embed.set_footer(text='Please click "Dismiss Message" to clear the menu.', icon_url=ICON)
      await interaction.response.send_message(embed=embed, ephemeral=True)
    elif self.values[0] == "5":
      embed = discord.Embed(title="", color=warna, description="""## 👷Jasa SA-MP
      
```Untuk jasa SA-MP anda bisa memilih untuk jasa seperti dev, setup dll sebagainya```
<:paket:1179761619786534983>**__Developer Rp150,000/Bulan__**
> By <@1006178204622540911>

<:paket:1179761619786534983>**__Setup Server Rp10,000__**
> By <@1135197516879634484>

<:paket:1179761619786534983>**__Fix Error Gamemodes Rp15,000__**
> By <@1135197516879634484>

<:paket:1179761619786534983>**__Bot Monitoring Rp15,000__**
> By <@1135197516879634484> 

📮Mau order bisa langsung [Pesan Sekarang](https://discord.com/channels/1100826060188299360/1172910051560804554)
      """)
      embed.set_footer(text='Please click "Dismiss Message" to clear the menu.', icon_url=ICON)
      await interaction.response.send_message(embed=embed, ephemeral=True)


class SelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout = None)
        self.add_item(Select())