import discord, json
from discord.ext import commands
from discord.ui import Select, View

warna = 0x2C2D31
with open('./config.json') as c:
  config = json.load(c)
  ICON = config['ICON']
  PANEL_IMAGE = config['PANEL_IMAGE']
  
class BasicMC(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        
    @discord.ui.button(label="Addons", custom_id="addons1", style=discord.ButtonStyle.grey, emoji="<:folder_iconXCloud2:1179772781341200505>")
    async def tutorial(self, interaction: discord.Interaction, button: discord.Button):
      embed = discord.Embed(title="", color=warna, description="""## <:folder_iconXCloud2:1179772781341200505> Addons Minecraft
      
```Disini kami menawarkan addons dengan harga yang murah cuy untuk dana pelajar siap menampung```
<:paket:1179761619786534983>**__Players (1 SLOT) <:panah:1179771346855678002> Rp1,000__**
<:paket:1179761619786534983>**__Monitoring Servers <:panah:1179771346855678002> Rp25,000__**

📮Mau order bisa langsung [Pesan Sekarang](https://discord.com/channels/1100826060188299360/1172910051560804554)
      """)
      embed.set_footer(text='Please click "Dismiss Message" to clear the menu.', icon_url=ICON)
      await interaction.response.edit_message(embed=embed)
      
    @discord.ui.button(label="Back", custom_id="back1", style=discord.ButtonStyle.grey, emoji="🔙")
    async def back(self, interaction: discord.Interaction, button: discord.Button):
      embed = discord.Embed(title="",color=warna, description = """## <:minecraft:1182004196879380530>Hosting Minecraft Basic

```Basic cloud rekomendasi untuk server menengah kebawah dengan harga yang sangat murah, untuk kecepatan sangat bagus ping rendah dan sudah ada anti DDoS Basic\n\nCpu: ∞\nRam: ∞\nDisk: ∞\nBandwidth: ∞```
<:paket:1179761619786534983>**__Paket#1 (25 SLOT) <:panah:1179771346855678002> Rp35,000__**
<:paket:1179761619786534983>**__Paket#2 (35 SLOT) <:panah:1179771346855678002> Rp50,000__**
<:paket:1179761619786534983>**__Paket#5 (80 SLOT) <:panah:1179771346855678002> Rp125,000__**
<:apalah:1179761511367975023>
  <:tambah_iconXCloud2:1179773147231293530>Include Database Online - Phpmyadmin Access
  <:tambah_iconXCloud2:1179773147231293530>Include Panel Management - untuk mengontrol server
  <:tambah_iconXCloud2:1179773147231293530>Include SFTP untuk memudahkan transfer file
  <:tambah_iconXCloud2:1179773147231293530>Include Anti DDoS Basic by XCloud

### <:informasi:1181621768646053969>Information
Untuk hosting ini adalah sharing, untuk Minecraft menggunakan egg Custom

📮Mau order bisa langsung [Pesan Sekarang](https://discord.com/channels/1100826060188299360/1172910051560804554)

🎮**__Tampilan Hosting__**
      """)
      embed.set_footer(text='Please click "Dismiss Message" to clear the menu.', icon_url=ICON)
      embed.set_image(url=PANEL_IMAGE)
      await interaction.response.edit_message(embed=embed)